package com.example.stejskalappmob

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_main.*
import org.json.JSONArray
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.POST

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var tahani:Retrofit = Retrofit.Builder()
            .baseUrl(PripojeniAPI.URL_FREEGAME)
            .addConverterFactory(GsonConverterFactory.create()).build()
        var datazAPI:PripojeniAPI = tahani.create(PripojeniAPI::class.java)
        var volam:Call<List<HodnotyzAPI?>?>? = datazAPI.posts
        volam?.enqueue(object:Callback<List<HodnotyzAPI?>?>
        {
            override fun onFailure(volam:Call<List<HodnotyzAPI?>?>, t: Throwable)
            {
            }
            override fun onResponse(volam: Call<List<HodnotyzAPI?>?>, odpoved: Response<List<HodnotyzAPI?>?>) {
                var obdrzenyseznam: List<HodnotyzAPI>? = odpoved.body() as List<HodnotyzAPI>
                var obdrzeny: Array<String?> = arrayOfNulls<String>(obdrzenyseznam!!.size)
                for (i: Int in obdrzenyseznam!!.indices) {
                    obdrzeny[i] = obdrzenyseznam!![i]!!.id.toString()
                }

        }
    })
}
}