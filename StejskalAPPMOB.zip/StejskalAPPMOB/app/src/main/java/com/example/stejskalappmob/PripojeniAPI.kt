package com.example.stejskalappmob

import retrofit2.Call
import retrofit2.http.GET

interface PripojeniAPI {

    @get:GET(value="posts")
    val posts : Call<List<HodnotyzAPI?>?>?
    companion object
    {
        const val URL_FREEGAME = "https://jsonplaceholder.typicode.com"
    }

}