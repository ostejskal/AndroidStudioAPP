package com.example.stejskalappmob

import com.google.gson.annotations.SerializedName;
import java.util.*

class HodnotyzAPI{
    var userId = 0
    var id = 0
    var title:String? = null
    var body:String? = null
    //var thumbnail:String? = null /*obrazek*/
    //var short_description:String? = null
    //var game_url:String? = null
    //var genre:String? = null
    //var platform:String? = null
    //var publisher:String? = null
    //var developer:String? = null
    //var release_date:String? = null
    //var freetogame_profile_url:String? = null
}