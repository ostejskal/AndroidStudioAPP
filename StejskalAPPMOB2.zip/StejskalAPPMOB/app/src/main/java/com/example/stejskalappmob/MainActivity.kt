package com.example.stejskalappmob

import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


/*class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var tahani = Retrofit.Builder()
            .baseUrl(PripojeniAPI.URL_FREEGAME)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        var datazAPI:PripojeniAPI = tahani.create(PripojeniAPI::class.java)
        var volam:Call<List<HodnotyzAPI?>?>? = datazAPI.posts
        volam?.enqueue(object:Callback<List<HodnotyzAPI?>?>{
            override fun onResponse(
                call: Call<List<HodnotyzAPI?>?>,
                response: Response<List<HodnotyzAPI?>?>
            ) {
                var obdrzenyseznam: List<HodnotyzAPI>? = response.body() as List<HodnotyzAPI>
                var obdrzeny: Array<String?> = arrayOfNulls<String>(obdrzenyseznam!!.size)
                for (i: Int in obdrzenyseznam!!.indices) {
                    obdrzeny[i] = obdrzenyseznam!![i]!!.title
                }
                var adapter = ArrayAdapter<String>(
                    applicationContext,
                    android.R.layout.simple_dropdown_item_1line,
                    obdrzeny
                )
                listview.adapter = adapter
            }

            override fun onFailure(call: Call<List<HodnotyzAPI?>?>, t: Throwable) {
                val list = mutableListOf(
                    "Nefunguju!"
                )
                var adapter = ArrayAdapter<String>(
                    applicationContext,
                    android.R.layout.simple_dropdown_item_1line,
                    list
                )
                listview.adapter = adapter
            }

        })
    }
}*/

class MainActivity : AppCompatActivity() {
    private var weatherData: TextView? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        weatherData = findViewById(R.id.textview2)
        findViewById<View>(R.id.button).setOnClickListener { getCurrentData() }
    }
    internal fun getCurrentData() {
        val retrofit = Retrofit.Builder()
            .baseUrl(BaseUrl)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        val service = retrofit.create(WeatherService::class.java)
        val call = service.getCurrentWeatherData()
        call.enqueue(object : Callback<List<WeatherResponse>> {
            override fun onResponse(
                call: Call<List<WeatherResponse>>,
                response: Response<List<WeatherResponse>>
            ) {
                if (response.code() == 200) {
                    val weatherResponse = response.body()!!

                    /*val stringBuilder = "Country: " +
                            weatherResponse.sys!!.country +
                            "\n" +
                            "Temperature: " +
                            weatherResponse.main!!.temp +
                            "\n" +
                            "Temperature(Min): " +
                            weatherResponse.main!!.temp_min +
                            "\n" +
                            "Temperature(Max): " +
                            weatherResponse.main!!.temp_max +
                            "\n" +
                            "Humidity: " +
                            weatherResponse.main!!.humidity +
                            "\n" +
                            "Pressure: " +
                            weatherResponse.main!!.pressure*/

                    /*val stringBuilder = "UserID: " + weatherResponse.userId + "\n"
                            "ID: " + weatherResponse.id + "\n"
                    "Title: " + weatherResponse.title + "\n"
                    "Body: " + weatherResponse.body+ "\n"


                    weatherData!!.text = stringBuilder*/
                    var obdrzenyseznam: List<WeatherResponse>? = response.body() as List<WeatherResponse>
                    var obdrzeny: Array<String?> = arrayOfNulls<String>(obdrzenyseznam!!.size)
                    for (i: Int in obdrzenyseznam!!.indices) {
                        /*obdrzeny[i] = obdrzenyseznam!![i]!!.userId.toString()
                        obdrzeny[i] = obdrzenyseznam!![i]!!.id.toString()*/
                        obdrzeny[i] = obdrzenyseznam!![i]!!.title
                        /*obdrzeny[i] = obdrzenyseznam!![i]!!.body*/
                    }
                    /*val stringBuilder = "UserID: " + weatherResponse.userId + "\n"
                    "ID: " + weatherResponse.id + "\n"
                    "Title: " + weatherResponse.title + "\n"
                    "Body: " + weatherResponse.body+ "\n"*/
                    weatherData!!.text = obdrzeny[1]
                   /* var adapter = ArrayAdapter<String>(
                        applicationContext,
                        android.R.layout.simple_dropdown_item_1line,
                        obdrzeny
                    )
                    listview.adapter = adapter*/
                }
            }

            override fun onFailure(call: Call<List<WeatherResponse>>, t: Throwable) {
                weatherData!!.text = t.message
            }
        })
    }
    companion object {

        /*var BaseUrl = "http://api.openweathermap.org/"*/
        /*var BaseUrl = "https://jsonplaceholder.typicode.com/"*/ // works
        var BaseUrl = "https://www.freetogame.com/"
        /*var AppId = "com.example.stejskalappmob"
        var lat = "35"
        var lon = "139"*/
    }
}