package com.example.stejskalappmob

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface WeatherService {
    @GET("/api/games?")
    fun getCurrentWeatherData(): Call<List<WeatherResponse>>
}